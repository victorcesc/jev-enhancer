package fiado_test

import (
	"net/url"
	"testing"

	"pdv/api-go/internal/fiado"
)

func TestNewPage_defaultsAndValues(t *testing.T) {
	cases := []struct {
		name  string
		query url.Values
		want  fiado.Page
	}{
		{"empty", url.Values{}, fiado.Page{Number: fiado.DefaultPage, Limit: fiado.DefaultLimit}},
		{"blank values", url.Values{"page": {""}, "limit": {""}}, fiado.Page{Number: 1, Limit: fiado.DefaultLimit}},
		{"explicit", url.Values{"page": {"4"}, "limit": {"10"}}, fiado.Page{Number: 4, Limit: 10}},
		{"max limit", url.Values{"limit": {"100"}}, fiado.Page{Number: 1, Limit: fiado.MaxLimit}},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := fiado.NewPage(tc.query)
			if err != nil {
				t.Fatalf("NewPage: %v", err)
			}
			if got != tc.want {
				t.Fatalf("got %+v, want %+v", got, tc.want)
			}
		})
	}
}

func TestNewPage_invalid(t *testing.T) {
	cases := map[string]url.Values{
		"page zero":      {"page": {"0"}},
		"page negative":  {"page": {"-1"}},
		"page not a int": {"page": {"abc"}},
		"limit zero":     {"limit": {"0"}},
		"limit negative": {"limit": {"-5"}},
		"limit not int":  {"limit": {"x"}},
		"limit over max": {"limit": {"101"}},
		"page over max":  {"page": {"1000001"}},
		"page overflows": {"page": {"99999999999999"}},
	}

	for name, query := range cases {
		t.Run(name, func(t *testing.T) {
			_, err := fiado.NewPage(query)
			assertAppError(t, err, 400, "VALIDATION_ERROR")
		})
	}
}

func TestPageOffsetAndTotalPages(t *testing.T) {
	page := fiado.Page{Number: 3, Limit: 20}
	if got := page.Offset(); got != 40 {
		t.Fatalf("Offset() = %d, want 40", got)
	}

	cases := []struct {
		total int64
		want  int64
	}{{0, 0}, {1, 1}, {20, 1}, {21, 2}, {41, 3}}
	for _, tc := range cases {
		if got := page.TotalPages(tc.total); got != tc.want {
			t.Fatalf("TotalPages(%d) = %d, want %d", tc.total, got, tc.want)
		}
	}
}
