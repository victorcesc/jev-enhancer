package middleware_test

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"pdv/api-go/internal/config"
	"pdv/api-go/internal/middleware"
)

func TestAPIKey(t *testing.T) {
	const secret = "secret"

	tests := []struct {
		name       string
		cfg        *config.Config
		method     string
		path       string
		headers    map[string]string
		wantStatus int
		wantCode   string
	}{
		{
			name:       "public route",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodGet,
			path:       "/health",
			wantStatus: http.StatusOK,
		},
		{
			name:       "no API key configured",
			cfg:        &config.Config{},
			method:     http.MethodGet,
			path:       "/notas/process",
			wantStatus: http.StatusOK,
		},
		{
			name:       "OPTIONS skips API key check",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodOptions,
			path:       "/notas/process",
			wantStatus: http.StatusOK,
		},
		{
			name:       "missing header",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodPost,
			path:       "/notas/process",
			wantStatus: http.StatusUnauthorized,
			wantCode:   "UNAUTHORIZED",
		},
		{
			name:       "invalid header",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodPost,
			path:       "/notas/process",
			headers:    map[string]string{"X-API-Key": "wrong"},
			wantStatus: http.StatusUnauthorized,
			wantCode:   "UNAUTHORIZED",
		},
		{
			name:       "valid header",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodPost,
			path:       "/notas/process",
			headers:    map[string]string{"X-API-Key": secret},
			wantStatus: http.StatusOK,
		},
		{
			name:   "sync with bearer skips API key",
			cfg:    &config.Config{APIKey: secret},
			method: http.MethodGet,
			path:   "/sync/initial",
			headers: map[string]string{
				"Authorization": "Bearer token_1_123",
			},
			wantStatus: http.StatusOK,
		},
		{
			name:       "sync without bearer requires API key",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodGet,
			path:       "/sync/initial",
			wantStatus: http.StatusUnauthorized,
		},
		{
			name:   "fiado with bearer skips API key",
			cfg:    &config.Config{APIKey: secret},
			method: http.MethodGet,
			path:   "/api/v1/customers/42/fiado",
			headers: map[string]string{
				"Authorization": "Bearer token_1_123",
			},
			wantStatus: http.StatusOK,
		},
		{
			name:       "fiado without bearer requires API key",
			cfg:        &config.Config{APIKey: secret},
			method:     http.MethodGet,
			path:       "/api/v1/customers/42/fiado",
			wantStatus: http.StatusUnauthorized,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			handler := middleware.APIKey(tc.cfg)(okHandler())

			req := httptest.NewRequest(tc.method, tc.path, nil)
			for k, v := range tc.headers {
				req.Header.Set(k, v)
			}

			rec := httptest.NewRecorder()
			handler.ServeHTTP(rec, req)

			if rec.Code != tc.wantStatus {
				t.Fatalf("status = %d, want %d", rec.Code, tc.wantStatus)
			}
			if tc.wantCode != "" {
				assertJSONError(t, rec, tc.wantStatus, tc.wantCode)
			}
		})
	}
}

func okHandler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
}
