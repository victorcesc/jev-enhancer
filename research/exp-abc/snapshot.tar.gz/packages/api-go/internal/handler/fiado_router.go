package handler

import (
	"github.com/go-chi/chi/v5"

	"pdv/api-go/internal/auth"
	"pdv/api-go/internal/fiado"
	apimw "pdv/api-go/internal/middleware"
)

// FiadoDeps groups dependencies for /api/v1/customers routes.
type FiadoDeps struct {
	Users   apimw.UserLookup
	Tokens  auth.AccessTokenParser
	Pending PendingFiadoLister
}

// MountFiado registers GET /api/v1/customers/{id}/fiado.
func MountFiado(router chi.Router, deps FiadoDeps) {
	router.Route("/api/v1/customers", func(r chi.Router) {
		r.Use(apimw.Bearer(deps.Users, deps.Tokens))
		r.Get("/{id}/fiado", CustomerFiado(deps.Pending))
	})
}

// Compile-time check for FiadoDeps services.
var _ PendingFiadoLister = (*fiado.PendingService)(nil)
