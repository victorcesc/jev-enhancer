-- Fiado (vendas a crédito) em aberto por cliente.
-- Paridade com SaleRepository::find_pending_credit_sales_by_customer (desktop):
-- is_credit, status 'completed' e total pago menor que o total da venda.

-- name: GetCustomerByUserIDAndID :one
SELECT
    id,
    user_id,
    name,
    document,
    phone,
    email,
    address,
    active,
    created_at,
    updated_at
FROM customers
WHERE id = sqlc.arg(id)
  AND user_id = sqlc.arg(user_id);

-- name: ListPendingFiadoSalesByCustomer :many
SELECT
    s.id,
    s.sale_date,
    s.total,
    COALESCE(p.total_paid, 0)::NUMERIC AS total_paid,
    (s.total - COALESCE(p.total_paid, 0))::NUMERIC AS balance
FROM sales s
LEFT JOIN (
    SELECT sale_id, SUM(amount) AS total_paid
    FROM payments
    GROUP BY sale_id
) p ON p.sale_id = s.id
WHERE s.user_id = sqlc.arg(user_id)
  AND s.customer_id = sqlc.arg(customer_id)::INT
  AND s.is_credit = TRUE
  AND s.status = 'completed'
  AND COALESCE(p.total_paid, 0) < s.total
ORDER BY s.sale_date DESC, s.id DESC
LIMIT sqlc.arg(row_limit)
OFFSET sqlc.arg(row_offset);

-- name: SummarizePendingFiadoSalesByCustomer :one
SELECT
    COUNT(*)::BIGINT AS total_sales,
    COALESCE(SUM(s.total - COALESCE(p.total_paid, 0)), 0)::NUMERIC AS total_devido
FROM sales s
LEFT JOIN (
    SELECT sale_id, SUM(amount) AS total_paid
    FROM payments
    GROUP BY sale_id
) p ON p.sale_id = s.id
WHERE s.user_id = sqlc.arg(user_id)
  AND s.customer_id = sqlc.arg(customer_id)::INT
  AND s.is_credit = TRUE
  AND s.status = 'completed'
  AND COALESCE(p.total_paid, 0) < s.total;
