package main

import (
	"context"
	"log"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/go-chi/chi/v5"
	chimiddleware "github.com/go-chi/chi/v5/middleware"
	"github.com/jackc/pgx/v5/pgxpool"

	"pdv/api-go/internal/auth"
	"pdv/api-go/internal/config"
	"pdv/api-go/internal/db"
	"pdv/api-go/internal/fiado"
	"pdv/api-go/internal/handler"
	"pdv/api-go/internal/httpx"
	apimw "pdv/api-go/internal/middleware"
	"pdv/api-go/internal/nfe"
	"pdv/api-go/internal/sync"
)

const (
	healthDBPingTimeout = 2 * time.Second
	shutdownTimeout     = 15 * time.Second
	serviceName         = "pdv-api-go"
)

type healthResponse struct {
	Status    string       `json:"status"`
	Timestamp string       `json:"timestamp"`
	Service   string       `json:"service"`
	Database  healthDBInfo `json:"database"`
}

type healthDBInfo struct {
	Status string `json:"status"`
	Error  string `json:"error,omitempty"`
}

func writeHealth(writer http.ResponseWriter, request *http.Request, pool *pgxpool.Pool) {
	resp := healthResponse{
		Status:    "ok",
		Timestamp: time.Now().UTC().Format(time.RFC3339Nano),
		Service:   serviceName,
		Database:  healthDBInfo{Status: "unknown"},
	}

	if pool != nil {
		ctx, cancel := context.WithTimeout(request.Context(), healthDBPingTimeout)
		defer cancel()
		if err := pool.Ping(ctx); err != nil {
			resp.Database.Status = "error"
			resp.Database.Error = err.Error()
		} else {
			resp.Database.Status = "ok"
		}
	}

	if err := httpx.WriteJSON(writer, http.StatusOK, resp); err != nil {
		log.Printf("health: encode json: %v", err)
	}
}

func main() {
	cfg, err := config.Load()
	if err != nil {
		log.Fatal(err)
	}

	logger := slog.New(slog.NewTextHandler(os.Stdout, &slog.HandlerOptions{
		Level: slog.LevelInfo,
	}))

	ctx := context.Background()

	var pool *pgxpool.Pool
	if dbURL := cfg.DatabaseURL; dbURL != "" {
		poolCfg, err := pgxpool.ParseConfig(dbURL)
		if err != nil {
			log.Fatalf("invalid DATABASE_URL: %v", err)
		}
		pool, err = pgxpool.NewWithConfig(ctx, poolCfg)
		if err != nil {
			log.Fatalf("database pool: %v", err)
		}
		defer pool.Close()
		logger.Info("database pool ready", "max_conns", pool.Stat().MaxConns())
	} else {
		logger.Warn("DATABASE_URL not set; server running without database pool")
	}

	if cfg.HasAPIKey() {
		prefix := cfg.APIKey
		if len(prefix) > 5 {
			prefix = prefix[:5]
		}
		logger.Info("API_KEY configured", "prefix", prefix+"...")
	} else {
		logger.Warn("API_KEY not set; development mode without x-api-key enforcement")
	}

	router := chi.NewRouter()
	router.Use(chimiddleware.RequestID)
	router.Use(apimw.CORS)
	router.Use(apimw.RequestLogger(logger))
	router.Use(chimiddleware.RealIP)
	router.Use(apimw.APIKey(cfg))
	router.Use(apimw.Recover(logger, cfg.IsProduction()))

	router.Get("/health", func(writer http.ResponseWriter, request *http.Request) {
		writeHealth(writer, request, pool)
	})

	if cfg.IsDevelopment() {
		router.Route("/dev", func(r chi.Router) {
			r.Get("/app-error", apimw.HandlerFunc(cfg.IsProduction(), handler.DevAppError))
			r.Get("/panic", handler.DevPanic)
			r.Post("/echo-json", apimw.HandlerFunc(cfg.IsProduction(), handler.DevReadJSON))
		})
		logger.Info("development routes mounted", "prefix", "/dev")
	}

	if pool != nil {
		queries := db.New(pool)
		tokenIssuer := auth.NewTokenIssuer(cfg.JWTSecret, cfg.JWTAccessTTL)
		sessions := auth.NewSessionService(tokenIssuer, queries, queries, cfg.JWTRefreshTTL)
		register := auth.NewRegisterService(pool, auth.QueriesRegisterStore(queries), sessions)
		login := auth.NewLoginService(queries, sessions)
		handler.MountAuth(router, handler.AuthDeps{
			Users:         queries,
			Keys:          queries,
			Register:      register,
			Login:         login,
			Session:       sessions,
			SessionRevoke: sessions,
			MeStore:       queries,
			Tokens:        tokenIssuer,
		})
		uploadStore := sync.QueriesUploadStore(queries)
		handler.MountSync(router, handler.SyncDeps{
			Users:   queries,
			Tokens:  tokenIssuer,
			Initial: sync.NewInitialService(queries),
			Upload:  sync.NewUploadService(pool, uploadStore),
		})
		handler.MountNotas(router, handler.NotasDeps{
			Users:    queries,
			Tokens:   tokenIssuer,
			Provider: nfe.NewMockProvider(),
		})
		handler.MountFiado(router, handler.FiadoDeps{
			Users:   queries,
			Tokens:  tokenIssuer,
			Pending: fiado.NewPendingService(queries),
		})
		logger.Info("auth routes mounted", "prefix", "/auth")
		logger.Info("sync routes mounted", "prefix", "/sync")
		logger.Info("notas routes mounted", "prefixes", "/notas,/invoices", "provider", "mock")
		logger.Info("fiado routes mounted", "prefix", "/api/v1/customers")
	} else {
		logger.Warn("auth routes disabled without DATABASE_URL")
	}

	srv := &http.Server{
		Addr:    cfg.HTTPAddr,
		Handler: router,
	}

	go func() {
		logger.Info("pdv-api-go listening", "env", cfg.Env, "addr", cfg.HTTPAddr)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error("listen failed", "err", err)
			os.Exit(1)
		}
	}()

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	signal.Stop(quit)
	logger.Info("shutdown signal received, draining HTTP server")

	shutdownCtx, cancel := context.WithTimeout(context.Background(), shutdownTimeout)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil {
		logger.Error("HTTP server shutdown", "err", err)
	}
	logger.Info("pdv-api-go stopped")
}
