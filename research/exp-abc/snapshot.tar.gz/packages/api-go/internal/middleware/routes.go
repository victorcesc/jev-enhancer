package middleware

import (
	"net/http"
	"strings"
)

// Route lists mirror packages/api/src/middleware/auth.ts.
var (
	publicRoutePrefixes = []string{
		"/health",
		"/auth/register",
		"/auth/login",
		"/auth/generate-registration-key",
	}

	bearerRoutePrefixes = []string{
		"/sync/",
		"/invoices/",
		"/notas/",
		"/auth/me",
		"/api/v1/customers/",
	}
)

const headerAPIKey = "X-API-Key"

func isPreflight(r *http.Request) bool {
	return r.Method == http.MethodOptions
}

func pathMatchesAny(path string, prefixes []string) bool {
	for _, prefix := range prefixes {
		if strings.HasPrefix(path, prefix) {
			return true
		}
	}
	return false
}

func hasBearerToken(h http.Header) bool {
	return strings.HasPrefix(h.Get("Authorization"), "Bearer ")
}

func clientAPIKey(h http.Header) string {
	return strings.TrimSpace(h.Get(headerAPIKey))
}
