package handler_test

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/go-chi/chi/v5"

	"pdv/api-go/internal/apperror"
	"pdv/api-go/internal/auth"
	"pdv/api-go/internal/db"
	"pdv/api-go/internal/fiado"
	"pdv/api-go/internal/handler"
)

const fiadoUserID int32 = 5

type stubPendingFiadoLister struct {
	out fiado.PendingResponse
	err error

	gotUserID     int32
	gotCustomerID int32
	gotPage       fiado.Page
}

func (s *stubPendingFiadoLister) ListPending(_ context.Context, userID, customerID int32, page fiado.Page) (fiado.PendingResponse, error) {
	s.gotUserID = userID
	s.gotCustomerID = customerID
	s.gotPage = page
	return s.out, s.err
}

// newFiadoRouter mounts the fiado routes with a bearer-authenticated stub user.
func newFiadoRouter(t *testing.T, lister handler.PendingFiadoLister) (chi.Router, string) {
	t.Helper()
	issuer := auth.NewTestTokenIssuer()
	token, err := issuer.IssueAccessToken(fiadoUserID)
	if err != nil {
		t.Fatal(err)
	}

	router := chi.NewRouter()
	handler.MountFiado(router, handler.FiadoDeps{
		Users:   stubUserLookup{user: db.User{ID: fiadoUserID}},
		Tokens:  issuer,
		Pending: lister,
	})
	return router, token
}

func doFiadoRequest(t *testing.T, router chi.Router, token, target string) *httptest.ResponseRecorder {
	t.Helper()
	req := httptest.NewRequest(http.MethodGet, target, nil)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	router.ServeHTTP(rec, req)
	return rec
}

func TestCustomerFiado_success(t *testing.T) {
	saleDate := time.Date(2026, 3, 4, 12, 0, 0, 0, time.UTC)
	lister := &stubPendingFiadoLister{out: fiado.PendingResponse{
		Success:    true,
		CustomerID: 42,
		Data: []fiado.PendingSale{{
			SaleID: 11, Data: saleDate, ValorOriginal: 100, ValorPago: 30, Saldo: 70,
		}},
		TotalDevido: 70,
		Pagination:  fiado.Pagination{Page: 1, Limit: 20, Total: 1, TotalPages: 1},
	}}

	router, token := newFiadoRouter(t, lister)
	rec := doFiadoRequest(t, router, token, "/api/v1/customers/42/fiado")

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
	}

	var got fiado.PendingResponse
	if err := json.NewDecoder(rec.Body).Decode(&got); err != nil {
		t.Fatal(err)
	}
	if !got.Success || got.TotalDevido != 70 || len(got.Data) != 1 {
		t.Fatalf("got %+v", got)
	}
	if got.Data[0].SaleID != 11 || got.Data[0].Saldo != 70 {
		t.Fatalf("sale = %+v", got.Data[0])
	}

	if lister.gotUserID != fiadoUserID || lister.gotCustomerID != 42 {
		t.Fatalf("service got user %d customer %d", lister.gotUserID, lister.gotCustomerID)
	}
	if lister.gotPage != (fiado.Page{Number: fiado.DefaultPage, Limit: fiado.DefaultLimit}) {
		t.Fatalf("page = %+v, want defaults", lister.gotPage)
	}
}

// The JSON must carry the keys the desktop client reads, in snake_case.
func TestCustomerFiado_responseKeys(t *testing.T) {
	lister := &stubPendingFiadoLister{out: fiado.PendingResponse{
		Success:    true,
		CustomerID: 42,
		Data: []fiado.PendingSale{{
			SaleID: 11, Data: time.Now(), ValorOriginal: 100, ValorPago: 30, Saldo: 70,
		}},
		TotalDevido: 70,
		Pagination:  fiado.Pagination{Page: 1, Limit: 20, Total: 1, TotalPages: 1},
	}}

	router, token := newFiadoRouter(t, lister)
	rec := doFiadoRequest(t, router, token, "/api/v1/customers/42/fiado")

	var body map[string]json.RawMessage
	if err := json.Unmarshal(rec.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{"success", "customer_id", "data", "total_devido", "pagination"} {
		if _, ok := body[key]; !ok {
			t.Fatalf("missing key %q in %s", key, rec.Body.String())
		}
	}

	var items []map[string]json.RawMessage
	if err := json.Unmarshal(body["data"], &items); err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{"sale_id", "data", "valor_original", "valor_pago", "saldo"} {
		if _, ok := items[0][key]; !ok {
			t.Fatalf("missing key %q in data[0]: %s", key, rec.Body.String())
		}
	}
}

func TestCustomerFiado_forwardsPagination(t *testing.T) {
	lister := &stubPendingFiadoLister{out: fiado.PendingResponse{Success: true, Data: []fiado.PendingSale{}}}

	router, token := newFiadoRouter(t, lister)
	rec := doFiadoRequest(t, router, token, "/api/v1/customers/42/fiado?page=3&limit=5")

	if rec.Code != http.StatusOK {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
	}
	if lister.gotPage != (fiado.Page{Number: 3, Limit: 5}) {
		t.Fatalf("page = %+v, want {3 5}", lister.gotPage)
	}
}

func TestCustomerFiado_unknownCustomerIs404(t *testing.T) {
	lister := &stubPendingFiadoLister{
		err: apperror.New("Cliente não encontrado", http.StatusNotFound, "CUSTOMER_NOT_FOUND"),
	}

	router, token := newFiadoRouter(t, lister)
	rec := doFiadoRequest(t, router, token, "/api/v1/customers/999/fiado")

	if rec.Code != http.StatusNotFound {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
	}

	var got fiado.FailureResponse
	if err := json.NewDecoder(rec.Body).Decode(&got); err != nil {
		t.Fatal(err)
	}
	if got.Success || got.Code != "CUSTOMER_NOT_FOUND" {
		t.Fatalf("got %+v", got)
	}
}

func TestCustomerFiado_invalidParams(t *testing.T) {
	cases := map[string]string{
		"non numeric id": "/api/v1/customers/abc/fiado",
		"zero id":        "/api/v1/customers/0/fiado",
		"id overflow":    "/api/v1/customers/99999999999/fiado",
		"page zero":      "/api/v1/customers/42/fiado?page=0",
		"limit over max": "/api/v1/customers/42/fiado?limit=101",
		"limit not int":  "/api/v1/customers/42/fiado?limit=abc",
	}

	for name, target := range cases {
		t.Run(name, func(t *testing.T) {
			lister := &stubPendingFiadoLister{}
			router, token := newFiadoRouter(t, lister)
			rec := doFiadoRequest(t, router, token, target)

			if rec.Code != http.StatusBadRequest {
				t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
			}
			if lister.gotCustomerID != 0 {
				t.Fatal("service was called for an invalid request")
			}
		})
	}
}

func TestCustomerFiado_requiresBearerToken(t *testing.T) {
	router, _ := newFiadoRouter(t, &stubPendingFiadoLister{})
	rec := doFiadoRequest(t, router, "", "/api/v1/customers/42/fiado")

	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
	}
}

func TestCustomerFiado_serviceFailureIs500(t *testing.T) {
	lister := &stubPendingFiadoLister{
		err: apperror.New("Erro ao buscar fiado do cliente", http.StatusInternalServerError, "INTERNAL_ERROR"),
	}

	router, token := newFiadoRouter(t, lister)
	rec := doFiadoRequest(t, router, token, "/api/v1/customers/42/fiado")

	if rec.Code != http.StatusInternalServerError {
		t.Fatalf("status = %d, body %s", rec.Code, rec.Body.String())
	}
}
