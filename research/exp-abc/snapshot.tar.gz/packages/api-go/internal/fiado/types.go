package fiado

import "time"

// Defaults and bounds for the page/limit query params of GET /api/v1/customers/{id}/fiado.
// MaxPage keeps (page-1)*limit inside int32, the SQL OFFSET type.
const (
	DefaultPage  = 1
	DefaultLimit = 20
	MaxLimit     = 100
	MaxPage      = 1_000_000
)

// PendingResponse is the success body from GET /api/v1/customers/{id}/fiado.
// TotalDevido soma o saldo de todas as vendas em aberto, não apenas as da página.
type PendingResponse struct {
	Success     bool          `json:"success"`
	CustomerID  int32         `json:"customer_id"`
	Data        []PendingSale `json:"data"`
	TotalDevido float64       `json:"total_devido"`
	Pagination  Pagination    `json:"pagination"`
}

// PendingSale is one fiado sale still open (valor pago menor que o valor original).
type PendingSale struct {
	SaleID        int32     `json:"sale_id"`
	Data          time.Time `json:"data"`
	ValorOriginal float64   `json:"valor_original"`
	ValorPago     float64   `json:"valor_pago"`
	Saldo         float64   `json:"saldo"`
}

// Pagination describes the returned page and the full result set.
type Pagination struct {
	Page       int   `json:"page"`
	Limit      int   `json:"limit"`
	Total      int64 `json:"total"`
	TotalPages int64 `json:"total_pages"`
}

// FailureResponse is the error body for fiado routes (same shape as sync.FailureResponse).
type FailureResponse struct {
	Success bool   `json:"success"`
	Message string `json:"message"`
	Code    string `json:"code,omitempty"`
}

// Page is a validated page/limit pair. Build it with NewPage.
type Page struct {
	Number int
	Limit  int
}

// Offset is the SQL OFFSET for the page.
func (p Page) Offset() int32 {
	return int32((p.Number - 1) * p.Limit)
}

// TotalPages is the number of pages needed for total rows at this limit.
func (p Page) TotalPages(total int64) int64 {
	if total <= 0 {
		return 0
	}
	limit := int64(p.Limit)
	return (total + limit - 1) / limit
}
