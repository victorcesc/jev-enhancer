package fiado_test

import (
	"context"
	"errors"
	"net/url"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"pdv/api-go/internal/apperror"
	"pdv/api-go/internal/db"
	"pdv/api-go/internal/fiado"
)

const (
	testUserID     int32 = 7
	testCustomerID int32 = 42
)

type stubStore struct {
	customer    db.Customer
	customerErr error

	rows    []db.ListPendingFiadoSalesByCustomerRow
	rowsErr error

	summary    db.SummarizePendingFiadoSalesByCustomerRow
	summaryErr error

	listParams db.ListPendingFiadoSalesByCustomerParams
}

func (s *stubStore) GetCustomerByUserIDAndID(_ context.Context, arg db.GetCustomerByUserIDAndIDParams) (db.Customer, error) {
	if s.customerErr != nil {
		return db.Customer{}, s.customerErr
	}
	if arg.ID != s.customer.ID || arg.UserID != s.customer.UserID {
		return db.Customer{}, pgx.ErrNoRows
	}
	return s.customer, nil
}

func (s *stubStore) ListPendingFiadoSalesByCustomer(_ context.Context, arg db.ListPendingFiadoSalesByCustomerParams) ([]db.ListPendingFiadoSalesByCustomerRow, error) {
	s.listParams = arg
	return s.rows, s.rowsErr
}

func (s *stubStore) SummarizePendingFiadoSalesByCustomer(_ context.Context, _ db.SummarizePendingFiadoSalesByCustomerParams) (db.SummarizePendingFiadoSalesByCustomerRow, error) {
	return s.summary, s.summaryErr
}

func mustNumeric(t *testing.T, s string) pgtype.Numeric {
	t.Helper()
	var n pgtype.Numeric
	if err := n.Scan(s); err != nil {
		t.Fatalf("scan numeric %q: %v", s, err)
	}
	return n
}

func knownCustomer() db.Customer {
	return db.Customer{ID: testCustomerID, UserID: testUserID, Name: "Cliente Fiado", Active: true}
}

func defaultPage(t *testing.T) fiado.Page {
	t.Helper()
	page, err := fiado.NewPage(url.Values{})
	if err != nil {
		t.Fatalf("NewPage: %v", err)
	}
	return page
}

func TestListPending_success(t *testing.T) {
	saleDate := time.Date(2026, 3, 4, 12, 0, 0, 0, time.UTC)
	store := &stubStore{
		customer: knownCustomer(),
		summary: db.SummarizePendingFiadoSalesByCustomerRow{
			TotalSales:  2,
			TotalDevido: mustNumeric(t, "130.00"),
		},
		rows: []db.ListPendingFiadoSalesByCustomerRow{
			{
				ID:        11,
				SaleDate:  pgtype.Timestamptz{Time: saleDate, Valid: true},
				Total:     mustNumeric(t, "100.00"),
				TotalPaid: mustNumeric(t, "30.00"),
				Balance:   mustNumeric(t, "70.00"),
			},
			{
				ID:        9,
				SaleDate:  pgtype.Timestamptz{Time: saleDate.Add(-24 * time.Hour), Valid: true},
				Total:     mustNumeric(t, "60.00"),
				TotalPaid: mustNumeric(t, "0"),
				Balance:   mustNumeric(t, "60.00"),
			},
		},
	}

	out, err := fiado.NewPendingService(store).
		ListPending(context.Background(), testUserID, testCustomerID, defaultPage(t))
	if err != nil {
		t.Fatalf("ListPending: %v", err)
	}

	if !out.Success || out.CustomerID != testCustomerID {
		t.Fatalf("got %+v", out)
	}
	if out.TotalDevido != 130 {
		t.Fatalf("TotalDevido = %v, want 130", out.TotalDevido)
	}
	if len(out.Data) != 2 {
		t.Fatalf("got %d sales, want 2", len(out.Data))
	}

	first := out.Data[0]
	if first.SaleID != 11 || !first.Data.Equal(saleDate) {
		t.Fatalf("first sale = %+v", first)
	}
	if first.ValorOriginal != 100 || first.ValorPago != 30 || first.Saldo != 70 {
		t.Fatalf("first amounts = %+v", first)
	}

	want := fiado.Pagination{Page: 1, Limit: fiado.DefaultLimit, Total: 2, TotalPages: 1}
	if out.Pagination != want {
		t.Fatalf("pagination = %+v, want %+v", out.Pagination, want)
	}
}

// total_devido must cover every open sale, not only the ones on the requested page.
func TestListPending_totalDevidoSpansAllPages(t *testing.T) {
	store := &stubStore{
		customer: knownCustomer(),
		summary: db.SummarizePendingFiadoSalesByCustomerRow{
			TotalSales:  5,
			TotalDevido: mustNumeric(t, "500.00"),
		},
		rows: []db.ListPendingFiadoSalesByCustomerRow{{
			ID:        3,
			SaleDate:  pgtype.Timestamptz{Time: time.Now(), Valid: true},
			Total:     mustNumeric(t, "100.00"),
			TotalPaid: mustNumeric(t, "0"),
			Balance:   mustNumeric(t, "100.00"),
		}},
	}

	page, err := fiado.NewPage(url.Values{"page": {"3"}, "limit": {"2"}})
	if err != nil {
		t.Fatalf("NewPage: %v", err)
	}

	out, err := fiado.NewPendingService(store).
		ListPending(context.Background(), testUserID, testCustomerID, page)
	if err != nil {
		t.Fatalf("ListPending: %v", err)
	}

	if out.TotalDevido != 500 {
		t.Fatalf("TotalDevido = %v, want 500 (all open sales)", out.TotalDevido)
	}
	if store.listParams.RowLimit != 2 || store.listParams.RowOffset != 4 {
		t.Fatalf("limit/offset = %d/%d, want 2/4", store.listParams.RowLimit, store.listParams.RowOffset)
	}

	want := fiado.Pagination{Page: 3, Limit: 2, Total: 5, TotalPages: 3}
	if out.Pagination != want {
		t.Fatalf("pagination = %+v, want %+v", out.Pagination, want)
	}
}

func TestListPending_emptyDataIsNotNull(t *testing.T) {
	store := &stubStore{
		customer: knownCustomer(),
		summary: db.SummarizePendingFiadoSalesByCustomerRow{
			TotalSales:  0,
			TotalDevido: mustNumeric(t, "0"),
		},
	}

	out, err := fiado.NewPendingService(store).
		ListPending(context.Background(), testUserID, testCustomerID, defaultPage(t))
	if err != nil {
		t.Fatalf("ListPending: %v", err)
	}

	if out.Data == nil {
		t.Fatal("Data = nil, want empty slice")
	}
	if out.TotalDevido != 0 || out.Pagination.Total != 0 || out.Pagination.TotalPages != 0 {
		t.Fatalf("got %+v", out)
	}
}

func TestListPending_unknownCustomerIs404(t *testing.T) {
	store := &stubStore{customer: knownCustomer()}

	_, err := fiado.NewPendingService(store).
		ListPending(context.Background(), testUserID, 999, defaultPage(t))

	assertAppError(t, err, 404, "CUSTOMER_NOT_FOUND")
}

// A customer owned by another user must not leak: the query filters by user_id.
func TestListPending_customerOfAnotherUserIs404(t *testing.T) {
	store := &stubStore{customer: knownCustomer()}

	_, err := fiado.NewPendingService(store).
		ListPending(context.Background(), testUserID+1, testCustomerID, defaultPage(t))

	assertAppError(t, err, 404, "CUSTOMER_NOT_FOUND")
}

func TestListPending_storeFailures(t *testing.T) {
	boom := errors.New("boom")

	cases := map[string]*stubStore{
		"customer lookup": {customer: knownCustomer(), customerErr: boom},
		"summary":         {customer: knownCustomer(), summaryErr: boom},
		"list":            {customer: knownCustomer(), rowsErr: boom},
	}

	for name, store := range cases {
		t.Run(name, func(t *testing.T) {
			_, err := fiado.NewPendingService(store).
				ListPending(context.Background(), testUserID, testCustomerID, defaultPage(t))
			assertAppError(t, err, 500, "INTERNAL_ERROR")
		})
	}
}

func assertAppError(t *testing.T, err error, status int, code string) {
	t.Helper()
	var appErr *apperror.AppError
	if !errors.As(err, &appErr) {
		t.Fatalf("err = %v, want *apperror.AppError", err)
	}
	if appErr.StatusCode != status || appErr.Code != code {
		t.Fatalf("err = %d/%s, want %d/%s", appErr.StatusCode, appErr.Code, status, code)
	}
}
