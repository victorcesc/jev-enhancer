package handler

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"

	"pdv/api-go/internal/apperror"
	"pdv/api-go/internal/auth"
	"pdv/api-go/internal/fiado"
	"pdv/api-go/internal/httpx"
)

// PendingFiadoLister loads data for GET /api/v1/customers/{id}/fiado.
type PendingFiadoLister interface {
	ListPending(ctx context.Context, userID, customerID int32, page fiado.Page) (fiado.PendingResponse, error)
}

// CustomerFiado handles GET /api/v1/customers/{id}/fiado.
func CustomerFiado(lister PendingFiadoLister) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		userID, ok := auth.UserIDFromContext(r.Context())
		if !ok {
			writeFiadoFailure(w, apperror.New("Usuário não autenticado", http.StatusUnauthorized, "UNAUTHENTICATED"))
			return
		}

		customerID, err := customerIDParam(chi.URLParam(r, "id"))
		if err != nil {
			writeFiadoFailure(w, err)
			return
		}

		page, err := fiado.NewPage(r.URL.Query())
		if err != nil {
			writeFiadoFailure(w, err)
			return
		}

		out, err := lister.ListPending(r.Context(), userID, customerID, page)
		if err != nil {
			writeFiadoFailure(w, err)
			return
		}

		_ = httpx.WriteJSON(w, http.StatusOK, out)
	}
}

// customerIDParam parses {id} as a positive int32 (customers.id is SERIAL).
func customerIDParam(raw string) (int32, error) {
	value, err := strconv.ParseInt(raw, 10, 32)
	if err != nil || value < 1 {
		return 0, apperror.New("ID do cliente inválido", http.StatusBadRequest, "VALIDATION_ERROR")
	}
	return int32(value), nil
}

func writeFiadoFailure(w http.ResponseWriter, err error) {
	var appErr *apperror.AppError
	if !errors.As(err, &appErr) {
		_ = httpx.WriteJSON(w, http.StatusInternalServerError, fiado.FailureResponse{
			Success: false,
			Message: "Erro ao buscar fiado do cliente",
			Code:    "INTERNAL_ERROR",
		})
		return
	}
	_ = httpx.WriteJSON(w, appErr.StatusCode, fiado.FailureResponse{
		Success: false,
		Message: appErr.Message,
		Code:    appErr.Code,
	})
}
