package fiado

import (
	"net/http"
	"net/url"
	"strconv"

	"pdv/api-go/internal/apperror"
)

// NewPage validates page/limit from a query string. Missing or empty values fall back
// to DefaultPage/DefaultLimit; anything else must be an integer within range.
func NewPage(query url.Values) (Page, error) {
	number, err := positiveIntParam(query, "page", DefaultPage, MaxPage)
	if err != nil {
		return Page{}, err
	}

	limit, err := positiveIntParam(query, "limit", DefaultLimit, MaxLimit)
	if err != nil {
		return Page{}, err
	}

	return Page{Number: number, Limit: limit}, nil
}

// positiveIntParam parses query[name] as an integer between 1 and max.
func positiveIntParam(query url.Values, name string, fallback, max int) (int, error) {
	raw := query.Get(name)
	if raw == "" {
		return fallback, nil
	}

	value, err := strconv.Atoi(raw)
	if err != nil || value < 1 {
		return 0, apperror.New(
			"Parâmetro "+name+" inválido",
			http.StatusBadRequest,
			"VALIDATION_ERROR",
		)
	}
	if value > max {
		return 0, apperror.New(
			"Parâmetro "+name+" acima do máximo de "+strconv.Itoa(max),
			http.StatusBadRequest,
			"VALIDATION_ERROR",
		)
	}

	return value, nil
}
