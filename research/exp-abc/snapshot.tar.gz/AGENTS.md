# AGENTS.md

Guidance for AI agents working in this repository.

## Project Overview

This is a PDV monorepo for a point-of-sale system.

- `packages/desktop`: Tauri 2 desktop app with React, TypeScript, Vite, Rust, and local SQLite.
- `packages/api-go`: Cloud API in Go with Chi, pgx, sqlc, goose migrations, PostgreSQL, JWT auth, sync endpoints, and mock NF-e provider.
- Root `package.json`: npm workspace entrypoint for the desktop package plus helper scripts for API and build commands.

The business domain is Brazilian POS terminology. Preserve existing names such as PDV, PAF, NFC-e, fiado, notas, and sync unless the task explicitly asks for a rename.

## Repository Layout

- `README.md`: high-level setup and commands.
- `packages/desktop/src`: React UI, routes, contexts, services, utilities, and CSS.
- `packages/desktop/src-tauri/src`: Rust/Tauri backend, commands, SQLite repositories, services, printer, sync, PAF, and models.
- `packages/desktop/src-tauri/src/database`: SQLite connection and migrations used by the desktop app.
- `packages/api-go/cmd/server`: Go API entrypoint.
- `packages/api-go/internal`: Go application packages. Keep private app code here; do not add `pkg/` for private code.
- `packages/api-go/query`: source SQL queries for sqlc.
- `packages/api-go/db/schema.sql`: source schema used by sqlc.
- `packages/api-go/internal/db`: generated sqlc Go code. Do not edit by hand.
- `packages/api-go/migrations`: goose PostgreSQL migrations.

## Required Tooling

- Node.js `>=20` and npm `>=9`.
- Go as declared in `packages/api-go/go.mod`.
- Rust stable for Tauri builds.
- PostgreSQL for API integration tests and local API development.
- Docker/Compose is optional for the API local stack.

## Common Commands

Run commands from the repository root unless noted.

- Install dependencies: `npm install`
- Start Vite desktop frontend: `npm run dev`
- Start Tauri desktop app: `npm run dev:desktop:tauri`
- Build desktop frontend: `npm run build`
- Build Tauri desktop app: `npm run build:desktop:tauri`
- Typecheck workspaces: `npm run typecheck`
- Start Go API: `npm run dev:api`
- Build Go API: `make -C packages/api-go build`
- Run Go tests: `make -C packages/api-go test`
- Run Go integration tests: set `TEST_DATABASE_URL` or `DATABASE_URL`, then `make -C packages/api-go test-integration`
- Generate sqlc code: `make -C packages/api-go sqlc`
- Run migrations: set `DATABASE_URL`, then `make -C packages/api-go migrate-up`
- Start API Docker stack: copy `packages/api-go/.env.example` to `packages/api-go/.env`, adjust values, then `make -C packages/api-go docker-up`
- Stop API Docker stack: `make -C packages/api-go docker-down`

For Rust-only checks in the desktop backend, run from `packages/desktop`: `cargo check` or `cargo test`.

## Environment

- API env example: `packages/api-go/.env.example`.
- Desktop env values must use Vite prefixes, for example `VITE_API_URL` or the existing `VITE_API_BASE_URL` usage.
- Never commit real `.env` files, tokens, keys, API credentials, database dumps, or customer fiscal data.
- The Go API reads configuration from environment variables; the Makefile only exports `packages/api-go/.env` for targets run from that directory.

## Go API Guidelines

- Follow `.cursor/rules/RULES.md` for Go conventions in this repository.
- Prefer standard library packages before adding dependencies, especially `net/http`, `context`, and `log/slog`.
- Functions that perform or may perform network I/O should accept `context.Context` as the first parameter named `ctx`.
- Return errors from lower layers and log at process or handler boundaries.
- Wrap inspectable errors with `%w`.
- Use table-driven tests for pure logic and `httptest` for HTTP behavior.
- Keep SQL source in `packages/api-go/query` and `packages/api-go/db/schema.sql`, then regenerate `internal/db` with `make -C packages/api-go sqlc`.
- Do not manually edit generated files under `packages/api-go/internal/db`.
- For database changes, update both the goose migration path and sqlc schema/query sources when needed.

## Desktop Guidelines

- React code lives in `packages/desktop/src`; Tauri Rust code lives in `packages/desktop/src-tauri/src`.
- Keep TypeScript strict-clean. The desktop build runs `tsc && vite build`.
- Frontend calls into Tauri commands through `@tauri-apps/api/core` `invoke` wrappers in `src/services`.
- When adding or renaming a Tauri command, update both the Rust command registration and the TypeScript service wrapper/types.
- Preserve existing UI structure and Portuguese user-facing copy unless asked otherwise.
- SQLite schema and data behavior for the desktop app belong in the Rust database/repository/service layers, not directly in React components.
- Do not introduce browser-only APIs in code that must run inside the Tauri backend.

## Testing And Verification

Choose the narrowest verification that covers the change.

- Frontend TypeScript/UI change: `npm run build:desktop` or `npm run typecheck`.
- Tauri/Rust backend change: run `cargo check` from `packages/desktop`; use `cargo test` when tests exist or behavior is covered.
- Go API pure/backend change: `make -C packages/api-go test`.
- Go DB/query/migration change: run `make -C packages/api-go sqlc`, then `make -C packages/api-go test`; use integration tests when database behavior changed.
- Root scripts/package changes: run the affected `npm run ...` command from root.

If a command cannot run because required services or env vars are missing, report that clearly with the exact missing prerequisite.

## Dependency Policy

- Keep changes minimal and use existing libraries/patterns first.
- Add third-party modules only when there is a clear benefit; mention the reason in the final response or PR description.
- Keep `package-lock.json`, `go.sum`, and Cargo lockfiles consistent with manifest changes.

## Generated And Build Artifacts

- Do not edit generated sqlc files in `packages/api-go/internal/db` manually.
- Do not commit `node_modules`, local database files, build output, or `.env` files.
- Before changing ignored/local files, verify they are intentionally part of the task.

## Collaboration Rules

- Do not revert user changes unless explicitly asked.
- Prefer small, targeted changes over broad rewrites.
- Update documentation when commands, env vars, package layout, or setup behavior changes.
- Keep final responses concise and include what changed plus what verification was run.
