package fiado

import (
	"context"
	"errors"
	"net/http"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"pdv/api-go/internal/apperror"
	"pdv/api-go/internal/db"
)

// PendingStore loads the rows behind GET /api/v1/customers/{id}/fiado.
type PendingStore interface {
	GetCustomerByUserIDAndID(ctx context.Context, arg db.GetCustomerByUserIDAndIDParams) (db.Customer, error)
	ListPendingFiadoSalesByCustomer(ctx context.Context, arg db.ListPendingFiadoSalesByCustomerParams) ([]db.ListPendingFiadoSalesByCustomerRow, error)
	SummarizePendingFiadoSalesByCustomer(ctx context.Context, arg db.SummarizePendingFiadoSalesByCustomerParams) (db.SummarizePendingFiadoSalesByCustomerRow, error)
}

// PendingService lists the fiado sales a customer has not settled yet.
type PendingService struct {
	store PendingStore
}

func NewPendingService(store PendingStore) *PendingService {
	return &PendingService{store: store}
}

// ListPending returns one page of open fiado sales plus the total owed across all of them.
// Returns a 404 AppError when the customer does not belong to the user (or does not exist).
func (s *PendingService) ListPending(ctx context.Context, userID, customerID int32, page Page) (PendingResponse, error) {
	if _, err := s.store.GetCustomerByUserIDAndID(ctx, db.GetCustomerByUserIDAndIDParams{
		ID:     customerID,
		UserID: userID,
	}); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return PendingResponse{}, apperror.New("Cliente não encontrado", http.StatusNotFound, "CUSTOMER_NOT_FOUND")
		}
		return PendingResponse{}, internalError()
	}

	summary, err := s.store.SummarizePendingFiadoSalesByCustomer(ctx, db.SummarizePendingFiadoSalesByCustomerParams{
		UserID:     userID,
		CustomerID: customerID,
	})
	if err != nil {
		return PendingResponse{}, internalError()
	}

	out := PendingResponse{
		Success:     true,
		CustomerID:  customerID,
		Data:        []PendingSale{},
		TotalDevido: numericFloat(summary.TotalDevido),
		Pagination: Pagination{
			Page:       page.Number,
			Limit:      page.Limit,
			Total:      summary.TotalSales,
			TotalPages: page.TotalPages(summary.TotalSales),
		},
	}

	rows, err := s.store.ListPendingFiadoSalesByCustomer(ctx, db.ListPendingFiadoSalesByCustomerParams{
		UserID:     userID,
		CustomerID: customerID,
		RowLimit:   int32(page.Limit),
		RowOffset:  page.Offset(),
	})
	if err != nil {
		return PendingResponse{}, internalError()
	}

	for _, row := range rows {
		saleDate, _ := timestamptzTime(row.SaleDate)
		out.Data = append(out.Data, PendingSale{
			SaleID:        row.ID,
			Data:          saleDate,
			ValorOriginal: numericFloat(row.Total),
			ValorPago:     numericFloat(row.TotalPaid),
			Saldo:         numericFloat(row.Balance),
		})
	}

	return out, nil
}

func internalError() error {
	return apperror.New("Erro ao buscar fiado do cliente", http.StatusInternalServerError, "INTERNAL_ERROR")
}

func numericFloat(n pgtype.Numeric) float64 {
	f, err := n.Float64Value()
	if err != nil || !f.Valid {
		return 0
	}
	return f.Float64
}

func timestamptzTime(t pgtype.Timestamptz) (time.Time, bool) {
	if !t.Valid {
		return time.Time{}, false
	}
	return t.Time, true
}
