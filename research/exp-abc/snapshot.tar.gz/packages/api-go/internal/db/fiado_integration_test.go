package db_test

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgtype"

	"pdv/api-go/internal/db"
	"pdv/api-go/internal/testutil"
)

// numericFloat reads a pgtype.Numeric as float64; amounts here have 2 decimals,
// so exact float comparison is safe.
func numericFloat(t *testing.T, n pgtype.Numeric) float64 {
	t.Helper()
	f, err := n.Float64Value()
	if err != nil {
		t.Fatalf("Float64Value: %v", err)
	}
	if !f.Valid {
		t.Fatal("numeric is NULL, want a value")
	}
	return f.Float64
}

func TestPendingFiadoQueries(t *testing.T) {
	pool, queries, cleanup := testutil.OpenDB(t)
	defer cleanup()

	ctx := context.Background()

	suffix := time.Now().UnixNano() % 1_000_000_000_000
	var userID, otherUserID int32
	err := pool.QueryRow(ctx, `
		INSERT INTO users (login, name, password, cnpj, razao_social, uf)
		VALUES ($1, 'Test Fiado', 'hash', $2, 'Test LTDA', 'SC')
		RETURNING id`,
		fmt.Sprintf("test_fiado_%d", suffix), fmt.Sprintf("%014d", suffix+1)).Scan(&userID)
	if err != nil {
		t.Fatalf("seed user: %v", err)
	}
	err = pool.QueryRow(ctx, `
		INSERT INTO users (login, name, password, cnpj, razao_social, uf)
		VALUES ($1, 'Outro', 'hash', $2, 'Outro LTDA', 'SC')
		RETURNING id`,
		fmt.Sprintf("test_fiado_other_%d", suffix), fmt.Sprintf("%014d", suffix+2)).Scan(&otherUserID)
	if err != nil {
		t.Fatalf("seed other user: %v", err)
	}

	var customerID int32
	if err := pool.QueryRow(ctx, `
		INSERT INTO customers (user_id, name) VALUES ($1, 'Cliente Fiado') RETURNING id`,
		userID).Scan(&customerID); err != nil {
		t.Fatalf("seed customer: %v", err)
	}

	var productID int32
	if err := pool.QueryRow(ctx, `
		INSERT INTO products (user_id, code, name, price) VALUES ($1, 'P-FIADO', 'Produto', 10.00)
		RETURNING id`, userID).Scan(&productID); err != nil {
		t.Fatalf("seed product: %v", err)
	}

	// Seeded sales, newest first: only "aberta" and "parcial" are open fiado.
	seedSale := func(name string, daysAgo int, total string, isCredit bool, status string, payments ...string) int32 {
		t.Helper()
		var saleID int32
		err := pool.QueryRow(ctx, `
			INSERT INTO sales (user_id, customer_id, sale_date, total, payment_method, is_credit, status)
			VALUES ($1, $2, NOW() - make_interval(days => $3), $4::NUMERIC, 'fiado', $5, $6)
			RETURNING id`,
			userID, customerID, daysAgo, total, isCredit, status).Scan(&saleID)
		if err != nil {
			t.Fatalf("seed sale %s: %v", name, err)
		}
		for _, amount := range payments {
			if _, err := pool.Exec(ctx, `
				INSERT INTO payments (sale_id, amount, payment_method)
				VALUES ($1, $2::NUMERIC, 'dinheiro')`, saleID, amount); err != nil {
				t.Fatalf("seed payment for %s: %v", name, err)
			}
		}
		return saleID
	}

	abertaID := seedSale("aberta", 1, "100.00", true, "completed")
	parcialID := seedSale("parcial", 2, "200.00", true, "completed", "50.00", "25.00")
	seedSale("quitada", 3, "80.00", true, "completed", "80.00")
	seedSale("a vista", 4, "30.00", false, "completed")
	seedSale("cancelada", 5, "90.00", true, "cancelled")

	// Same customer id must not match another user's sales.
	var otherCustomerID int32
	if err := pool.QueryRow(ctx, `
		INSERT INTO customers (user_id, name) VALUES ($1, 'Cliente Outro') RETURNING id`,
		otherUserID).Scan(&otherCustomerID); err != nil {
		t.Fatalf("seed other customer: %v", err)
	}

	t.Run("GetCustomerByUserIDAndID", func(t *testing.T) {
		got, err := queries.GetCustomerByUserIDAndID(ctx, db.GetCustomerByUserIDAndIDParams{
			ID: customerID, UserID: userID,
		})
		if err != nil {
			t.Fatalf("GetCustomerByUserIDAndID: %v", err)
		}
		if got.ID != customerID || got.Name != "Cliente Fiado" {
			t.Fatalf("got %+v", got)
		}

		_, err = queries.GetCustomerByUserIDAndID(ctx, db.GetCustomerByUserIDAndIDParams{
			ID: customerID, UserID: otherUserID,
		})
		if !errors.Is(err, pgx.ErrNoRows) {
			t.Fatalf("cross-user lookup err = %v, want pgx.ErrNoRows", err)
		}
	})

	t.Run("ListPendingFiadoSalesByCustomer", func(t *testing.T) {
		rows, err := queries.ListPendingFiadoSalesByCustomer(ctx, db.ListPendingFiadoSalesByCustomerParams{
			UserID: userID, CustomerID: customerID, RowLimit: 10, RowOffset: 0,
		})
		if err != nil {
			t.Fatalf("ListPendingFiadoSalesByCustomer: %v", err)
		}
		if len(rows) != 2 {
			t.Fatalf("got %d open sales, want 2 (aberta, parcial): %+v", len(rows), rows)
		}

		// sale_date DESC: aberta (1 day ago) before parcial (2 days ago).
		if rows[0].ID != abertaID || rows[1].ID != parcialID {
			t.Fatalf("order = %d,%d, want %d,%d", rows[0].ID, rows[1].ID, abertaID, parcialID)
		}
		if got := numericFloat(t, rows[0].TotalPaid); got != 0 {
			t.Fatalf("aberta total_paid = %v, want 0", got)
		}
		if got := numericFloat(t, rows[0].Balance); got != 100 {
			t.Fatalf("aberta balance = %v, want 100", got)
		}
		if got := numericFloat(t, rows[1].TotalPaid); got != 75 {
			t.Fatalf("parcial total_paid = %v, want 75", got)
		}
		if got := numericFloat(t, rows[1].Balance); got != 125 {
			t.Fatalf("parcial balance = %v, want 125", got)
		}
	})

	t.Run("ListPendingFiadoSalesByCustomer paginates", func(t *testing.T) {
		first, err := queries.ListPendingFiadoSalesByCustomer(ctx, db.ListPendingFiadoSalesByCustomerParams{
			UserID: userID, CustomerID: customerID, RowLimit: 1, RowOffset: 0,
		})
		if err != nil {
			t.Fatalf("page 1: %v", err)
		}
		second, err := queries.ListPendingFiadoSalesByCustomer(ctx, db.ListPendingFiadoSalesByCustomerParams{
			UserID: userID, CustomerID: customerID, RowLimit: 1, RowOffset: 1,
		})
		if err != nil {
			t.Fatalf("page 2: %v", err)
		}
		third, err := queries.ListPendingFiadoSalesByCustomer(ctx, db.ListPendingFiadoSalesByCustomerParams{
			UserID: userID, CustomerID: customerID, RowLimit: 1, RowOffset: 2,
		})
		if err != nil {
			t.Fatalf("page 3: %v", err)
		}

		if len(first) != 1 || first[0].ID != abertaID {
			t.Fatalf("page 1 = %+v", first)
		}
		if len(second) != 1 || second[0].ID != parcialID {
			t.Fatalf("page 2 = %+v", second)
		}
		if len(third) != 0 {
			t.Fatalf("page 3 = %+v, want empty", third)
		}
	})

	t.Run("SummarizePendingFiadoSalesByCustomer", func(t *testing.T) {
		summary, err := queries.SummarizePendingFiadoSalesByCustomer(ctx, db.SummarizePendingFiadoSalesByCustomerParams{
			UserID: userID, CustomerID: customerID,
		})
		if err != nil {
			t.Fatalf("SummarizePendingFiadoSalesByCustomer: %v", err)
		}
		if summary.TotalSales != 2 {
			t.Fatalf("total_sales = %d, want 2", summary.TotalSales)
		}
		// 100.00 (aberta) + 125.00 (parcial)
		if got := numericFloat(t, summary.TotalDevido); got != 225 {
			t.Fatalf("total_devido = %v, want 225", got)
		}
	})

	t.Run("SummarizePendingFiadoSalesByCustomer with no open sales", func(t *testing.T) {
		summary, err := queries.SummarizePendingFiadoSalesByCustomer(ctx, db.SummarizePendingFiadoSalesByCustomerParams{
			UserID: otherUserID, CustomerID: otherCustomerID,
		})
		if err != nil {
			t.Fatalf("SummarizePendingFiadoSalesByCustomer: %v", err)
		}
		if summary.TotalSales != 0 {
			t.Fatalf("total_sales = %d, want 0", summary.TotalSales)
		}
		if got := numericFloat(t, summary.TotalDevido); got != 0 {
			t.Fatalf("total_devido = %v, want 0", got)
		}
	})
}
